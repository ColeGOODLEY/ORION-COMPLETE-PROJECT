# ORION — Personal AI Operating System

ORION is a private, modular personal assistant project. This package preserves the supplied project and adds a web-research path, a Cloudflare Worker backend, and a foundation for permissioned app/device adapters.

## What is included
- Existing ORION modules for identity, personality, memory, context, reasoning, decisions, planning, voice, and HUD.
- Optional web research through a configurable SearXNG instance called from the Cloudflare Worker.
- Worker-side AI requests using the existing Hugging Face secret.
- An integration registry that reports capabilities honestly and requires explicit confirmation for consequential adapter actions.
- Setup and security instructions in `INSTALL_AND_SECURITY.md`.

## Important limitations
This is a codebase upgrade, not a fully deployed autonomous system. Web search requires a working HTTPS SearXNG endpoint and a deployed Worker. Email/calendar, smart-home, desktop, and hardware control require their own adapters, permissions, credentials, and supported devices. A static GitHub Pages site cannot safely store API secrets or directly control arbitrary hardware.

## Quick start
1. Upload the contents of this folder to the ORION GitHub repository, preserving folder structure.
2. Deploy `cloudflare-worker/worker.js` as the code for the existing Cloudflare Worker. Keep `HF_API_KEY` configured as a Cloudflare secret.
3. Configure `SEARXNG_URL` only after selecting and verifying a SearXNG instance that supports JSON search.
4. Follow `INSTALL_AND_SECURITY.md` and test the Worker before using ORION.
