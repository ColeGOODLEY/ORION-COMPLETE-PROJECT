# ORION Roadmap

## Included in this upgrade
- Existing modular intelligence pipeline preserved.
- Worker-backed AI connector with optional web-research routing.
- Search result/source context passed to the model without treating page text as instructions.
- Integration registry for status, adapter registration, browser notifications, and confirmation-gated actions.
- Safer text rendering of model output in the HUD.

## Next milestones (require configuration or additional code)
1. Deploy and secure the Worker; configure a reliable SearXNG source.
2. Improve research quality with full-page retrieval, source ranking, date extraction, and cross-source verification.
3. Build persistent structured memory with user review/edit/export controls.
4. Add authenticated app connectors one at a time (calendar/email/task system).
5. Add a local desktop/device bridge for hardware and operating-system actions; keep it authenticated and allowlisted.
6. Add smart-home integration through a supported platform and confirmation policies.
7. Package for additional devices after deciding target hardware and operating systems.

Local intelligence first. Cloud AI only when necessary. ORION remains a private personal system.
