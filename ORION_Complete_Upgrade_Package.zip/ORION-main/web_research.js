// =====================================
// ORION WEB RESEARCH
// Personal web-search routing and source formatting
// =====================================
// Search is performed server-side by the Cloudflare Worker. Never place API
// keys or provider credentials in this browser file or in the public repo.

const ORION_WEB_RESEARCH = {
    shouldSearch(command) {
        if (typeof command !== "string") return false;
        const text = command.trim().toLowerCase();
        if (!text) return false;

        const patterns = [
            /\b(search|look up|lookup|research|find sources|browse the web|search the web|on the internet|verify online|fact check)\b/,
            /\b(latest|current|currently|today|tonight|this week|this month|recent|right now|as of \d{4})\b/,
            /\b(news|weather|forecast|stock price|exchange rate|price today|release date|schedule|standings|statistics|election results|breaking)\b/,
            /\b(what is the price|how much does .* cost|is .* still available|who won|when does .* open)\b/,
            /\b(compare .* (colleges|universities|companies|products|cars|careers|programs)|best .* (colleges|universities|companies|products|cars|careers|programs)|recommend .* (colleges|universities|companies|products|cars|careers|programs))\b/,
            /\b(sources|citations|references|official website|official site)\b/
        ];
        return patterns.some(pattern => pattern.test(text));
    },

    formatResults(results) {
        if (!Array.isArray(results) || results.length === 0) {
            return "No web search results were returned. Do not invent sources or claim that the web was checked.";
        }
        return results.slice(0, 5).map((item, index) => {
            const title = String(item.title || "Untitled result").slice(0, 240);
            const url = String(item.url || "").slice(0, 1000);
            const snippet = String(item.content || item.snippet || "").slice(0, 1200);
            return `[${index + 1}] ${title}\nURL: ${url}\nSnippet: ${snippet}`;
        }).join("\n\n");
    }
};
