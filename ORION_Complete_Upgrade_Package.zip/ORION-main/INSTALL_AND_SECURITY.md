# ORION Upgrade — Install and Security Guide

## What to upload to GitHub
Upload the full contents of this `ORION-main` folder into the root of your existing ORION repository, keeping the directories and filenames intact. This package includes the original modules; it is not a set of instructions to delete modules. If GitHub asks to replace same-named files, the package's versions are intended to replace them. Keep a copy of the old ZIP/repository first.

## Cloudflare Worker (required for cloud AI)
1. Open Cloudflare Dashboard → Workers & Pages → the existing ORION Worker → Edit code.
2. Replace the Worker code with `cloudflare-worker/worker.js` from this package and deploy.
3. In Worker Settings → Variables and Secrets, keep `HF_API_KEY` as a **secret**. Do not paste it into GitHub, HTML, or JavaScript.
4. The Worker URL used by the browser is currently `https://sparkling-meadow-17f4.colehgoodley.workers.dev` in `ai_brain.js`. If your Worker URL differs, change `ORION_BRAIN.endpoint` to the actual URL.
5. Open the Worker URL in a browser. A JSON health response should appear. Then test normal ORION chat.

## Web search
Web search will not work until `SEARXNG_URL` is set to a real, trusted HTTPS SearXNG instance that permits `/search?q=...&format=json`. Set it as a normal Worker variable (not a secret). Public instances can disable JSON or throttle traffic; do not guess an endpoint. A reliable hosted instance may not be permanently free. Until configured, ORION is designed to say search is unavailable rather than pretend it searched.

## Secure the Worker before relying on it
The Worker is an internet-facing endpoint. Because a browser-based static site cannot keep a shared secret private, do not embed a secret token in frontend JavaScript and treat it as secure. Before regular personal use, add Cloudflare rate limiting and, if appropriate for your deployment, an access-control layer that fits your hosting setup. Restrict CORS to the actual site origin as a defense-in-depth measure, but remember CORS alone is not authentication. Monitor provider usage.

## Device and app integrations
`integration_manager.js` is a registry and safety boundary, not a finished connector to every app/device. Actual integrations need an adapter for the target system (for example, a supported smart-home platform, calendar provider, or a local desktop bridge). Grant the least privilege needed, store credentials server-side, and require confirmation for consequential actions such as sending messages, unlocking doors, spending money, or changing security settings.

## Test checklist
- [ ] Page loads and the command console appears.
- [ ] Ordinary chat returns a real model response through the Worker.
- [ ] Ask for current news; if SearXNG is not configured, ORION clearly says web search is unavailable.
- [ ] Once configured, check that researched answers include real source URLs and do not claim sources that were not returned.
- [ ] Check browser console for missing scripts/errors.
- [ ] Confirm provider secrets are not committed to the GitHub repository.

## Rollback
If the page breaks, restore the previous versions of any replaced files from your backup. Do not delete the old ZIP or old project copy until the new version is verified.
