// =====================================
// ORION INTEGRATION MANAGER
// Foundation Build 1.0
// =====================================
// This registry prepares a consistent interface for future app/device adapters.
// It does NOT magically grant browser access to local hardware or third-party
// accounts. Each adapter must be implemented, configured, and permissioned.

(function () {
    "use strict";

    const adapters = new Map();
    const capabilities = [
        { id: "browser-notifications", label: "Browser notifications", state: typeof Notification !== "undefined" ? "available" : "unsupported", requiresSetup: false },
        { id: "speech-recognition", label: "Browser speech recognition", state: ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) ? "available" : "unsupported", requiresSetup: false },
        { id: "speech-synthesis", label: "Browser text-to-speech", state: "speechSynthesis" in window ? "available" : "unsupported", requiresSetup: false },
        { id: "web-research", label: "Internet search via Worker", state: "requires-configuration", requiresSetup: true },
        { id: "smart-home", label: "Smart-home control", state: "not-connected", requiresSetup: true },
        { id: "desktop-device-bridge", label: "Local computer/device bridge", state: "not-connected", requiresSetup: true },
        { id: "calendar-email", label: "Calendar and email apps", state: "not-connected", requiresSetup: true }
    ];

    function safeStatus() {
        return capabilities.map(item => ({ ...item, connected: adapters.has(item.id) }));
    }

    const API = {
        version: "1.0.0",
        status() { return safeStatus(); },
        getCapabilities() { return safeStatus(); },

        registerAdapter(id, adapter) {
            if (typeof id !== "string" || !id.trim()) throw new TypeError("Adapter id is required.");
            if (!adapter || typeof adapter.execute !== "function") throw new TypeError("An adapter must provide execute(action, payload).");
            adapters.set(id, adapter);
            return { success: true, id };
        },

        unregisterAdapter(id) {
            return adapters.delete(id);
        },

        async requestAction(id, action, payload = {}, options = {}) {
            const adapter = adapters.get(id);
            if (!adapter) return { success: false, error: `Integration '${id}' is not connected.` };
            if (typeof action !== "string" || !action.trim()) return { success: false, error: "An action name is required." };
            // Any consequential action must require an explicit confirmation callback.
            if (options.requiresConfirmation === true) {
                if (typeof options.confirm !== "function") return { success: false, error: "Confirmation is required before this action." };
                const approved = await options.confirm({ id, action, payload });
                if (approved !== true) return { success: false, cancelled: true, error: "Action cancelled." };
            }
            try {
                return await adapter.execute(action, payload);
            } catch (error) {
                console.error("ORION integration action failed:", id, action, error);
                return { success: false, error: "The integration action failed." };
            }
        },

        async notify(title, body) {
            if (typeof Notification === "undefined") return { success: false, error: "Browser notifications are not supported here." };
            let permission = Notification.permission;
            if (permission === "default") permission = await Notification.requestPermission();
            if (permission !== "granted") return { success: false, error: "Notification permission was not granted." };
            new Notification(String(title || "ORION").slice(0, 100), { body: String(body || "").slice(0, 500) });
            return { success: true };
        }
    };

    window.ORION_INTEGRATIONS = API;

    function updateIntegrationLabel() {
        const label = document.getElementById("integration-status");
        if (!label) return;
        const active = safeStatus().filter(item => item.connected).length;
        label.textContent = active ? `${active} CONNECTED` : "SETUP REQUIRED";
    }

    function updateResearchLabel() {
        const label = document.getElementById("web-research-status");
        if (label) label.textContent = "WORKER SETUP";
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => { updateIntegrationLabel(); updateResearchLabel(); });
    } else {
        updateIntegrationLabel(); updateResearchLabel();
    }
})();
